# Time Tracker

## A plugin for Microsoft's PowerToys Run

### How to Install

1. Download the [latest release](https://github.com/Nuhser/PowerToysRun-TimeTracker/releases/latest) (e.g. `Release_1.x.x.zip`).
2. Unzip the archive. It should contain **one folder** named `TimeTracker`.
3. Exit PowerToys.
4. Copy the folder into the plugin-folder of your PowerToys Run (e.g. `%LOCALAPPDATA%\Microsoft\PowerToys\PowerToys Run\Plugins`).
5. Restart PowerToys Run.

You should now see **Time Tracker** inside your PowerToys Run Plugins. The default activation command is `+`.
